package com.example.loginappversion20;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.loginappversion20.data.DBHelper;
import com.example.loginappversion20.model.User;
import com.example.loginappversion20.util.Util;

import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends AppCompatActivity {

    Button loginButton;
    EditText name, password;
    TextView signUpText;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginButton = findViewById(R.id.loginButton);
        name = findViewById(R.id.name);
        password = findViewById(R.id.password);
        signUpText = findViewById(R.id.signupText);
        db = new DBHelper(this);

        // signup
        SpannableString signUptextString = new SpannableString("New User, SignUp Here");
        ClickableSpan clickableSpanSignUptextString = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent = new Intent(MainActivity.this, SignInActivity.class);
                startActivityForResult(intent,1);
            }
        };
        signUptextString.setSpan(clickableSpanSignUptextString, 17, 21, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        signUpText.setText(signUptextString);
        signUpText.setMovementMethod(LinkMovementMethod.getInstance());

        loginButton.setOnClickListener(v -> {
            Cursor cursor = db.getUserdata(name.getText().toString());
//            User user = db.getUserdata(name.getText().toString());
            if(cursor.getCount() == 0) Toast.makeText(this, "User not there", Toast.LENGTH_SHORT).show();
            String emailVal, passwordVal;
            emailVal = cursor.getString(0);
            passwordVal = cursor.getString(1);
            String decryptedPassword = decrypt(passwordVal);
//            Log.d("MAIN_TAG", "onCreate: "+ emailVal + " " + passwordVal);
            if (decryptedPassword.equals(password.getText().toString())){
                Toast.makeText(this,"Welcome",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Incorrect Password", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Boolean checkInsertedData = db.insertUserData(new User(data.getStringExtra(Util.KEY_NAME),data.getStringExtra(Util.KEY_PASSWORD)));
            if(checkInsertedData) Toast.makeText(this, "User Added", Toast.LENGTH_SHORT).show();
            else Toast.makeText(this, "User Not Added", Toast.LENGTH_SHORT).show();
        }
    }
    public String decrypt(String encryptedPassword) {
        try{
            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            IvParameterSpec ivspec = new IvParameterSpec(iv);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(Util.SECRET_KEY.toCharArray(), Util.SALT_VALUE.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
            return new String(cipher.doFinal(Base64.getDecoder().decode(encryptedPassword)));
        } catch (Exception e) {

        }
        return null;
    }
}