package com.example.loginappversion20;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.example.loginappversion20.model.PasswordStrength;
import com.example.loginappversion20.util.Util;

import java.nio.charset.StandardCharsets;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class SignInActivity extends AppCompatActivity {

    EditText name, password, confirmPassword, valIm;
    Button signInButton;
    PasswordStrength passwordStrength;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        name = findViewById(R.id.signInName);
        password = findViewById(R.id.signInPassword);
        confirmPassword = findViewById(R.id.signInConfirmPassword);
        signInButton = findViewById(R.id.signInButton);

        passwordStrength = new PasswordStrength(this);

        signInButton.setOnClickListener(v -> {
            if(password.getText().toString().equals(confirmPassword.getText().toString())) {
                if(passwordStrength.passwordCheck(password.getText().toString())){
                    Intent intent = new Intent();
                    intent.putExtra(Util.KEY_NAME, name.getText().toString());
                    String encryptedPassword = encrypt(password.getText().toString());
                    intent.putExtra(Util.KEY_PASSWORD, encryptedPassword);
                    setResult(RESULT_OK, intent);
                    finish();
                }

            }

        });
    }
    public String encrypt(String password) {
        try{
            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(Util.SECRET_KEY.toCharArray(), Util.SALT_VALUE.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKey secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
            return Base64.getEncoder().encodeToString(cipher.doFinal(password.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {

        }
        return null;
    }
}