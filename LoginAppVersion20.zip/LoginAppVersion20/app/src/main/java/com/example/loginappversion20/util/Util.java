package com.example.loginappversion20.util;

public class Util {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "users_db";
    public static final String TABLE_NAME = "users";

    // Users Table
    public static final String KEY_NAME = "name";
    public static final String KEY_PASSWORD = "password";

    public static final String SECRET_KEY = "123456789";
    public static final String SALT_VALUE = "abcdfeg";
}
