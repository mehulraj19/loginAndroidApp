package com.example.loginappversion20.model;

import android.content.Context;
import android.widget.Toast;

public class PasswordStrength {
    private Context context;
    String arr[] = {"!@#$%^&*()", "0123456789", "abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
    boolean check[] = {false, false, false, false};

    public PasswordStrength(Context context) {
        this.context = context;
    }

    public boolean passwordCheck(String password) {
        if(password.length() < 6) {
            Toast.makeText(context, "Password is too short!!", Toast.LENGTH_SHORT).show();
            return false;
        }
        for (int i=0; i<4; i++) {
            String s = arr[i];
            for(int j=0; j<s.length(); j++) {
                StringBuilder sb = new StringBuilder();
                sb.append(s.charAt(j));
                if(password.contains(sb)) {
                    check[i] = true;
                    break;
                }
            }
        }
        boolean res = check[0] & check[1] & check[2] & check[3];
        if (!res) Toast.makeText(context, "Password is not Strong!!", Toast.LENGTH_SHORT).show();
        return res;
    }
}
