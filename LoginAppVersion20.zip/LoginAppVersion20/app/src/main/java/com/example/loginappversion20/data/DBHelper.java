package com.example.loginappversion20.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.loginappversion20.model.User;
import com.example.loginappversion20.util.Util;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + Util.TABLE_NAME +  "("
                + Util.KEY_NAME +" TEXT PRIMARY KEY, "
                + Util.KEY_PASSWORD + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Util.TABLE_NAME);
    }

    public Boolean insertUserData(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Util.KEY_NAME, user.getName());
        values.put(Util.KEY_PASSWORD, user.getPassword());

        long res = db.insert(Util.TABLE_NAME, null, values);
        if (res == -1) return false;
        else return true;
    }
    public Cursor getUserdata(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME, new String[]{Util.KEY_NAME, Util.KEY_PASSWORD},
                Util.KEY_NAME + "=?", new String[]{name},
                null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }
        return  cursor;
    }

    public Boolean userExists(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME, new String[]{Util.KEY_NAME, Util.KEY_PASSWORD},
                Util.KEY_NAME + "=?", new String[]{name},
                null, null, null);
        if(cursor.getCount()>0) return true;
        else return false;
    }
    public int getCount(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + Util.TABLE_NAME, null);
        return cursor.getCount();
    }
}
