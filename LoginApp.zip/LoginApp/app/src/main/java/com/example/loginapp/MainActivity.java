package com.example.loginapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText enteredEmail;
    EditText enteredPassword;
    TextView signinText;
    Button loginButton;
    ArrayList<ArrayList<String>> arr = new ArrayList<ArrayList<String>>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        enteredEmail = findViewById(R.id.enteredEmail);
        enteredPassword = findViewById(R.id.enteredPassword);
        loginButton = findViewById(R.id.loginButton);
        signinText = findViewById(R.id.signupText);

        loginButton.setOnClickListener(v -> {

            if(arr.isEmpty()) {
                Toast.makeText(MainActivity.this ,"No user is there", Toast.LENGTH_SHORT).show();
            }else  {
                boolean isThere = false;
                int index = -1;
                String s = enteredEmail.getText().toString();
                for(int i=0; i<arr.size(); i++) {
                    String val = arr.get(i).get(0);
                    if(val.equals(s)) {
                        isThere = true;
                        index = i;
                        break;
                    }
                }
                if(isThere) {
                    if(arr.get(index).get(1).equals(enteredPassword.getText().toString())) {
                        Toast.makeText(MainActivity.this, "Welcome!!", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(MainActivity.this, "Password is incorrect!!", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(MainActivity.this, "The given user is not there!!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        SpannableString s = new SpannableString("New User, SIGNUP here");
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent = new Intent(MainActivity.this, signinActivity.class);
                startActivityForResult(intent, 1);
            }
        };
        s.setSpan(clickableSpan, 17, 21, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        signinText.setText(s);
        signinText.setMovementMethod(LinkMovementMethod.getInstance());

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1) {
            if(resultCode == RESULT_OK) {
                ArrayList<String> narr = new ArrayList<>();
                narr.add(data.getStringExtra("email"));
                narr.add(data.getStringExtra("password"));
                arr.add(narr);
            }
        }
    }
}